export const tools = {

    blacksmith: "кузнеца",
    brewer: "пивовара",
    mason: "каменщика",

}