export const armor = {

    light: "легкие",
    light_details: "—",

    medium: "средние",
    medium_details: "—",

    shields: "щиты",
    shields_details: "—",

}